# VANTA Client 0.1.0

Client-side Fabric mod starter for Minecraft Java 1.21.4.

## Included
- Premium dark/purple Click GUI (Right Shift)
- Toggle Sprint
- Hold C to zoom while Zoom module is enabled
- FPS, coordinates and ping HUD
- Optional keystrokes display
- Module state saved to `config/vanta.json`

## Build
- Install JDK 21
- Open this folder in IntelliJ IDEA / Android-compatible Gradle environment
- Run `gradle build`
- Output JAR: `build/libs/vanta-0.1.0.jar`

## Notes
This is a first playable foundation, not the final feature-complete client.
Some HUD rendering uses Fabric's deprecated `HudRenderCallback` API for compatibility with
the 1.21.4 target; it can be migrated later if needed.
