package com.vanta.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class VantaClient implements ClientModInitializer {
    public static final String MOD_ID = "vanta";
    public static final MinecraftClient MC = MinecraftClient.getInstance();
    public static final List<Module> MODULES = new ArrayList<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("vanta.json");

    private KeyBinding guiKey;
    private KeyBinding zoomKey;
    private double previousFov = 70.0;
    private boolean zoomWasActive = false;

    @Override
    public void onInitializeClient() {
        MODULES.clear();
        MODULES.add(new ToggleSprintModule());
        MODULES.add(new ZoomModule());
        MODULES.add(new HudModule());
        MODULES.add(new FpsModule());
        MODULES.add(new CoordinatesModule());
        MODULES.add(new PingModule());
        MODULES.add(new KeystrokesModule());

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vanta.open_gui", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.vanta.general"));

        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vanta.zoom", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_C, "category.vanta.general"));

        loadConfig();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new VantaScreen());
            }

            Module sprint = getModule("Toggle Sprint");
            if (sprint != null && sprint.enabled && client.player != null) {
                boolean movingForward = client.player.input != null
                        && client.player.input.movementForward > 0.0F;
                client.player.setSprinting(movingForward && !client.player.isSneaking());
            }

            updateZoom(client);
        });

        HudRenderCallback.EVENT.register((context, tickCounter) -> renderHud(context));
        System.out.println("[VANTA] VANTA Client 0.1.0 initialized");
    }

    private void updateZoom(MinecraftClient client) {
        Module zoom = getModule("Zoom");
        boolean active = zoom != null && zoom.enabled && zoomKey.isPressed()
                && client.player != null && client.currentScreen == null;

        if (active) {
            if (!zoomWasActive) {
                previousFov = client.options.getFov().getValue();
                zoomWasActive = true;
            }
            client.options.getFov().setValue(30);
        } else if (zoomWasActive) {
            client.options.getFov().setValue((int) previousFov);
            zoomWasActive = false;
        }
    }

    public static Module getModule(String name) {
        for (Module module : MODULES) {
            if (module.name.equalsIgnoreCase(name)) return module;
        }
        return null;
    }

    public static void saveConfig() {
        try {
            JsonObject root = new JsonObject();
            for (Module module : MODULES) root.addProperty(module.name, module.enabled);
            Files.createDirectories(CONFIG.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG)) {
                GSON.toJson(root, writer);
            }
        } catch (Exception e) {
            System.err.println("[VANTA] Could not save config: " + e.getMessage());
        }
    }

    private static void loadConfig() {
        if (!Files.exists(CONFIG)) return;
        try (Reader reader = Files.newBufferedReader(CONFIG)) {
            JsonObject root = GSON.fromJson(reader, JsonObject.class);
            if (root == null) return;
            for (Module module : MODULES) {
                if (root.has(module.name)) module.enabled = root.get(module.name).getAsBoolean();
            }
        } catch (Exception e) {
            System.err.println("[VANTA] Could not load config: " + e.getMessage());
        }
    }

    private static void renderHud(DrawContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        int x = 8;
        int y = 8;
        int white = 0xFFF2F0FA;
        int purple = 0xFFBD8CFF;

        if (isEnabled("HUD")) {
            context.fill(x - 4, y - 4, x + 112, y + 18, 0xAA11101A);
            context.drawText(mc.textRenderer, "VANTA", x, y, purple, true);
            y += 15;
        }
        if (isEnabled("FPS")) {
            context.drawText(mc.textRenderer, "FPS: " + mc.getCurrentFps(), x, y, white, true);
            y += 12;
        }
        if (isEnabled("Coordinates")) {
            String coords = String.format("XYZ: %d / %d / %d",
                    MathHelper.floor(mc.player.getX()),
                    MathHelper.floor(mc.player.getY()),
                    MathHelper.floor(mc.player.getZ()));
            context.drawText(mc.textRenderer, coords, x, y, white, true);
            y += 12;
        }
        if (isEnabled("Ping") && mc.getNetworkHandler() != null) {
            var entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (entry != null) {
                context.drawText(mc.textRenderer, "Ping: " + entry.getLatency() + " ms", x, y, white, true);
            }
        }

        if (isEnabled("Keystrokes")) {
            int bx = 8;
            int by = context.getScaledWindowHeight() - 58;
            drawKey(context, mc.options.forwardKey.isPressed() ? "W" : "W", bx + 22, by,
                    mc.options.forwardKey.isPressed());
            drawKey(context, "A", bx, by + 22, mc.options.leftKey.isPressed());
            drawKey(context, "S", bx + 22, by + 22, mc.options.backKey.isPressed());
            drawKey(context, "D", bx + 44, by + 22, mc.options.rightKey.isPressed());
            drawKey(context, "JUMP", bx + 66, by + 22, mc.options.jumpKey.isPressed());
        }
    }

    private static void drawKey(DrawContext context, String label, int x, int y, boolean pressed) {
        int bg = pressed ? 0xFF7042A5 : 0xCC171620;
        context.fill(x, y, x + (label.equals("JUMP") ? 42 : 20), y + 19, bg);
        context.drawBorder(x, y, label.equals("JUMP") ? 42 : 20, 19, 0xFF9C70D0);
        context.drawCenteredTextWithShadow(MC.textRenderer, label,
                x + (label.equals("JUMP") ? 21 : 10), y + 6, 0xFFFFFFFF);
    }

    private static boolean isEnabled(String name) {
        Module module = getModule(name);
        return module != null && module.enabled;
    }

    public static abstract class Module {
        protected final String name;
        protected boolean enabled;

        protected Module(String name, boolean defaultEnabled) {
            this.name = name;
            this.enabled = defaultEnabled;
        }

        public String getName() { return name; }
        public boolean isEnabled() { return enabled; }

        public void toggle() {
            enabled = !enabled;
            saveConfig();
        }
    }

    public static final class ToggleSprintModule extends Module {
        public ToggleSprintModule() { super("Toggle Sprint", false); }
    }
    public static final class ZoomModule extends Module {
        public ZoomModule() { super("Zoom", false); }
    }
    public static final class HudModule extends Module {
        public HudModule() { super("HUD", true); }
    }
    public static final class FpsModule extends Module {
        public FpsModule() { super("FPS", true); }
    }
    public static final class CoordinatesModule extends Module {
        public CoordinatesModule() { super("Coordinates", true); }
    }
    public static final class PingModule extends Module {
        public PingModule() { super("Ping", true); }
    }
    public static final class KeystrokesModule extends Module {
        public KeystrokesModule() { super("Keystrokes", false); }
    }

    public static class VantaScreen extends Screen {
        private static final int PANEL = 0xF011101B;
        private static final int HEADER = 0xFF261735;
        private static final int ACCENT = 0xFFB987F5;

        protected VantaScreen() {
            super(Text.literal("VANTA CLIENT"));
        }

        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float delta) {
            renderBackground(context, mouseX, mouseY, delta);
            int left = Math.max(20, (width - 360) / 2);
            int top = Math.max(20, (height - 300) / 2);
            int right = Math.min(width - 20, left + 360);

            context.fill(left, top, right, top + 300, PANEL);
            context.fill(left, top, right, top + 42, HEADER);
            context.drawText(textRenderer, "VANTA CLIENT", left + 16, top + 15, ACCENT, true);
            context.drawText(textRenderer, "1.21.4  |  PREMIUM", right - 126, top + 16, 0xFFBDB5C9, false);

            int y = top + 58;
            for (Module module : MODULES) {
                int color = module.enabled ? 0xFF4A2B69 : 0xFF24212B;
                context.fill(left + 14, y, right - 14, y + 27, color);
                context.drawText(textRenderer, module.name, left + 25, y + 9, 0xFFFFFFFF, false);
                String state = module.enabled ? "ON" : "OFF";
                int stateColor = module.enabled ? 0xFF72F0AD : 0xFFFF8585;
                context.drawText(textRenderer, state, right - 48, y + 9, stateColor, true);
                y += 34;
            }
            context.drawText(textRenderer, "Right Shift: menu     C: zoom while enabled",
                    left + 15, top + 278, 0xFFAAA1B5, false);
            super.render(context, mouseX, mouseY, delta);
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (button == 0) {
                int left = Math.max(20, (width - 360) / 2);
                int top = Math.max(20, (height - 300) / 2);
                int y = top + 58;
                for (Module module : MODULES) {
                    if (mouseX >= left + 14 && mouseX <= left + 346
                            && mouseY >= y && mouseY <= y + 27) {
                        module.toggle();
                        return true;
                    }
                    y += 34;
                }
            }
            return super.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public boolean shouldPause() { return false; }
    }
}
