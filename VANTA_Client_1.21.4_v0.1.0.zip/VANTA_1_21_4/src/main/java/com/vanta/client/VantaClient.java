
package com.vanta.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class VantaClient implements ClientModInitializer {

    private static MinecraftClient mc;

    private static KeyBinding guiKey;
    private static KeyBinding zoomKey;

    private static boolean zooming = false;
    private static double originalFov = 70.0;

    private static final List<Module> MODULES = new ArrayList<>();

    private static final int PURPLE = 0xFF9B59FF;
    private static final int DARK = 0xFF101018;
    private static final int PANEL = 0xFF191923;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFF9999AA;
    private static final int GREEN = 0xFF55DD99;
    private static final int RED = 0xFFFF6677;

    @Override
    public void onInitializeClient() {

        mc = MinecraftClient.getInstance();

        registerModules();

        guiKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding(
                "key.vanta.clickgui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "key.categories.misc"
            )
        );

        zoomKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding(
                "key.vanta.zoom",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_C,
                "key.categories.misc"
            )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {

            while (guiKey.wasPressed()) {
                client.setScreen(new VantaScreen());
            }

            updateModules(client);
            updateZoom(client);
        });

        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            renderHUD(context);
        });
    }

    private static void registerModules() {

        MODULES.clear();

        MODULES.add(new Module(
            "Toggle Sprint",
            "MOVEMENT",
            true
        ));

        MODULES.add(new Module(
            "Zoom",
            "RENDER",
            false
        ));

        MODULES.add(new Module(
            "Coordinates",
            "RENDER",
            true
        ));

        MODULES.add(new Module(
            "Player Info",
            "PLAYER",
            true
        ));

        MODULES.add(new Module(
            "HUD",
            "RENDER",
            true
        ));
    }

    private static void updateModules(MinecraftClient client) {

        if (client.player == null) {
            return;
        }

        Module sprint = getModule("Toggle Sprint");

        if (sprint != null && sprint.enabled) {
            if (!client.player.isSneaking()) {
                client.player.setSprinting(true);
            }
        }
    }

    private static void updateZoom(MinecraftClient client) {

        Module zoom = getModule("Zoom");

        if (client.options == null || client.player == null) {
            return;
        }

        boolean shouldZoom = zoom != null && zoom.enabled
                && zoomKey.isPressed();

        if (shouldZoom && !zooming) {
            originalFov = client.options.getFov().getValue();
            zooming = true;
        }

        if (shouldZoom) {
            client.options.getFov().setValue(30);
        } else if (zooming) {
            client.options.getFov().setValue((int) originalFov);
            zooming = false;
        }
    }

    private static void renderHUD(DrawContext ctx) {

        if (mc.player == null || mc.world == null) {
            return;
        }

        Module hud = getModule("HUD");

        if (hud == null || !hud.enabled) {
            return;
        }

        int x = 10;
        int y = 10;

        ctx.fill(x - 5, y - 5, x + 125, y + 18, DARK);
        ctx.fill(x - 5, y - 5, x - 2, y + 18, PURPLE);

        ctx.drawTextWithShadow(
            mc.textRenderer,
            Text.literal("VANTA CLIENT"),
            x + 3,
            y,
            PURPLE
        );

        Module coordinates = getModule("Coordinates");

        if (coordinates != null && coordinates.enabled) {

            String coords = String.format(
                "XYZ: %.1f / %.1f / %.1f",
                mc.player.getX(),
                mc.player.getY(),
                mc.player.getZ()
            );

            drawHUDText(ctx, coords, 10, 35, WHITE);
        }

        Module playerInfo = getModule("Player Info");

        if (playerInfo != null && playerInfo.enabled) {

            String info = "FPS: " + mc.getCurrentFps();

            drawHUDText(ctx, info, 10, 48, GREEN);
        }
    }

    private static void drawHUDText(
        DrawContext ctx,
        String text,
        int x,
        int y,
        int color
    ) {

        ctx.fill(
            x - 4,
            y - 3,
            x + mc.textRenderer.getWidth(text) + 5,
            y + 12,
            0xAA101018
        );

        ctx.drawTextWithShadow(
            mc.textRenderer,
            text,
            x,
            y,
            color
        );
    }

    private static Module getModule(String name) {

        for (Module module : MODULES) {
            if (module.name.equals(name)) {
                return module;
            }
        }

        return null;
    }

    private static List<Module> getCategoryModules(String category) {

        List<Module> result = new ArrayList<>();

        for (Module module : MODULES) {
            if (module.category.equals(category)) {
                result.add(module);
            }
        }

        return result;
    }

    private static class Module {

        String name;
        String category;
        boolean enabled;

        Module(String name, String category, boolean enabled) {
            this.name = name;
            this.category = category;
            this.enabled = enabled;
        }
    }

    private static class VantaScreen extends Screen {

        private final String[] categories = {
            "COMBAT",
            "MOVEMENT",
            "RENDER",
            "PLAYER"
        };

        private String selectedCategory = "MOVEMENT";

        private int panelX;
        private int panelY;
        private int panelWidth = 430;
        private int panelHeight = 280;

        protected VantaScreen() {
            super(Text.literal("VANTA CLIENT"));
        }

        @Override
        public void render(
            DrawContext ctx,
            int mouseX,
            int mouseY,
            float delta
        ) {

            ctx.fill(
                0,
                0,
                width,
                height,
                0x99000000
            );

            panelX = (width - panelWidth) / 2;
            panelY = (height - panelHeight) / 2;

            drawPanel(ctx);
            drawSidebar(ctx, mouseX, mouseY);
            drawModules(ctx, mouseX, mouseY);

            super.render(ctx, mouseX, mouseY, delta);
        }

        private void drawPanel(DrawContext ctx) {

            ctx.fill(
                panelX,
                panelY,
                panelX + panelWidth,
                panelY + panelHeight,
                DARK
            );

            ctx.fill(
                panelX,
                panelY,
                panelX + panelWidth,
                panelY + 3,
                PURPLE
            );

            ctx.fill(
                panelX + 115,
                panelY + 3,
                panelX + panelWidth,
                panelY + 35,
                PANEL
            );

            ctx.drawTextWithShadow(
                textRenderer,
                Text.literal("VANTA CLIENT"),
                panelX + 14,
                panelY + 13,
                PURPLE
            );

            ctx.drawTextWithShadow(
                textRenderer,
                Text.literal("2.0"),
                panelX + panelWidth - 35,
                panelY + 13,
                GRAY
            );

            ctx.fill(
                panelX + 115,
                panelY + 35,
                panelX + panelWidth,
                panelY + 36,
                0xFF30303D
            );
        }

        private void drawSidebar(
            DrawContext ctx,
            int mouseX,
            int mouseY
        ) {

            int sidebarX = panelX;
            int sidebarY = panelY + 36;

            ctx.fill(
                sidebarX,
                sidebarY,
                sidebarX + 115,
                panelY + panelHeight,
                PANEL
            );

            int y = sidebarY + 12;

            for (String category : categories) {

                boolean selected = category.equals(selectedCategory);

                boolean hovered =
                    mouseX >= sidebarX + 7 &&
                    mouseX <= sidebarX + 107 &&
                    mouseY >= y - 5 &&
                    mouseY <= y + 17;

                if (selected) {

                    ctx.fill(
                        sidebarX + 7,
                        y - 5,
                        sidebarX + 107,
                        y + 17,
                        0xFF302342
                    );

                    ctx.fill(
                        sidebarX + 7,
                        y - 5,
                        sidebarX + 10,
                        y + 17,
                        PURPLE
                    );

                } else if (hovered) {

                    ctx.fill(
                        sidebarX + 7,
                        y - 5,
                        sidebarX + 107,
                        y + 17,
                        0xFF252532
                    );
                }

                ctx.drawTextWithShadow(
                    textRenderer,
                    Text.literal(category),
                    sidebarX + 17,
                    y + 1,
                    selected ? PURPLE : WHITE
                );

                y += 34;
            }
        }

        private void drawModules(
            DrawContext ctx,
            int mouseX,
            int mouseY
        ) {

            int startX = panelX + 130;
            int startY = panelY + 53;

            ctx.drawTextWithShadow(
                textRenderer,
                Text.literal(selectedCategory),
                startX,
                startY - 3,
                PURPLE
            );

            List<Module> modules =
                getCategoryModules(selectedCategory);

            if (modules.isEmpty()) {

                ctx.drawTextWithShadow(
                    textRenderer,
                    Text.literal("No modules available"),
                    startX,
                    startY + 35,
                    GRAY
                );

                return;
            }

            int y = startY + 24;

            for (Module module : modules) {

                int cardWidth = 275;
                int cardHeight = 38;

                boolean hovered =
                    mouseX >= startX &&
                    mouseX <= startX + cardWidth &&
                    mouseY >= y &&
                    mouseY <= y + cardHeight;

                ctx.fill(
                    startX,
                    y,
                    startX + cardWidth,
                    y + cardHeight,
                    hovered ? 0xFF292936 : PANEL
                );

                ctx.drawTextWithShadow(
                    textRenderer,
                    Text.literal(module.name),
                    startX + 10,
                    y + 14,
                    WHITE
                );

                int toggleX = startX + cardWidth - 53;
                int toggleY = y + 10;

                int toggleColor =
                    module.enabled ? GREEN : RED;

                ctx.fill(
                    toggleX,
                    toggleY,
                    toggleX + 43,
                    toggleY + 19,
                    0xFF30303D
                );

                String state =
                    module.enabled ? "ON" : "OFF";

                int textX = toggleX +
                    (43 - textRenderer.getWidth(state)) / 2;

                ctx.drawTextWithShadow(
                    textRenderer,
                    state,
                    textX,
                    toggleY + 6,
                    toggleColor
                );

                y += 46;
            }
        }

        @Override
        public boolean mouseClicked(
            double mouseX,
            double mouseY,
            int button
        ) {

            if (button != 0) {
                return super.mouseClicked(mouseX, mouseY, button);
            }

            int sidebarX = panelX;
            int y = panelY + 48;

            for (String category : categories) {

                if (
                    mouseX >= sidebarX + 7 &&
                    mouseX <= sidebarX + 107 &&
                    mouseY >= y - 5 &&
                    mouseY <= y + 17
                ) {

                    selectedCategory = category;
                    return true;
                }

                y += 34;
            }

            int startX = panelX + 130;
            int startY = panelY + 77;

            List<Module> modules =
                getCategoryModules(selectedCategory);

            for (int i = 0; i < modules.size(); i++) {

                int moduleY = startY + (i * 46);

                if (
                    mouseX >= startX &&
                    mouseX <= startX + 275 &&
                    mouseY >= moduleY &&
                    mouseY <= moduleY + 38
                ) {

                    Module module = modules.get(i);
                    module.enabled = !module.enabled;

                    return true;
                }
            }

            return super.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public boolean shouldPause() {
            return false;
        }

        @Override
        public void close() {
            if (mc != null) {
                mc.setScreen(null);
            }
        }
    }
}
