
package com.vanta.client;

// VANTA CLIENT 2.0
// Minecraft 1.21.4 | Fabric | Java 21

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class VantaClient implements ClientModInitializer {

    private static final String VERSION = "2.0.0";
    private static MinecraftClient mc;
    private static KeyBinding guiKey;

    private static final List<Module> MODULES = new ArrayList<>();

    private static final int PURPLE = 0xFFAA66FF;
    private static final int DARK = 0xFF101018;
    private static final int PANEL = 0xFF191923;

    // CATEGORIES

    enum Category {
        COMBAT,
        MOVEMENT,
        RENDER,
        PLAYER
    }

    // MODULE BASE

    static abstract class Module {

        final String name;
        final String description;
        final Category category;

        boolean enabled = false;

        Module(String name, String description, Category category) {
            this.name = name;
            this.description = description;
            this.category = category;
        }

        void toggle() {
            setEnabled(!enabled);
        }

        void setEnabled(boolean state) {
            if (enabled == state) return;

            enabled = state;

            if (enabled) onEnable();
            else onDisable();
        }

        void onEnable() {}
        void onDisable() {}
        void onTick() {}
    }

    // MODULES

    static class Sprint extends Module {

        Sprint() {
            super("Toggle Sprint", "Automatic sprint", Category.MOVEMENT);
        }

        @Override
        void onTick() {
            if (mc.player == null) return;

            mc.player.setSprinting(
                mc.player.forwardSpeed > 0
                && !mc.player.isSneaking()
            );
        }
    }

    static class Zoom extends Module {

        private int oldFov = 70;

        Zoom() {
            super("Zoom", "Camera FOV control", Category.RENDER);
        }

        @Override
        void onEnable() {
            oldFov = mc.options.getFov().getValue();
            mc.options.getFov().setValue(35);
        }

        @Override
        void onDisable() {
            mc.options.getFov().setValue(oldFov);
        }
    }

    static class Hud extends Module {

        Hud() {
            super("HUD", "Client information", Category.RENDER);
        }
    }

    static class Coordinates extends Module {

        Coordinates() {
            super("Coordinates", "Player coordinates", Category.RENDER);
        }
    }

    static class PlayerInfo extends Module {

        PlayerInfo() {
            super("Player Info", "Player information", Category.PLAYER);
        }
    }

    // INITIALIZATION

    @Override
    public void onInitializeClient() {

        mc = MinecraftClient.getInstance();

        MODULES.add(new Sprint());
        MODULES.add(new Zoom());
        MODULES.add(new Hud());
        MODULES.add(new Coordinates());
        MODULES.add(new PlayerInfo());

        guiKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding(
                "key.vanta.gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC
            )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {

            while (guiKey.wasPressed()) {
                client.setScreen(new VantaGUI());
            }

            for (Module module : MODULES) {
                if (module.enabled) module.onTick();
            }
        });

        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            renderHud(context);
        });

        System.out.println("[VANTA] VERSION " + VERSION + " LOADED");
    }

    // MODULE LOOKUP

    private static Module getModule(String name) {

        for (Module module : MODULES) {
            if (module.name.equalsIgnoreCase(name)) {
                return module;
            }
        }

        return null;
    }

    // HUD

    private static void renderHud(DrawContext context) {

        if (mc.player == null) return;

        Module hud = getModule("HUD");
        Module coordinates = getModule("Coordinates");
        Module playerInfo = getModule("Player Info");

        if (hud != null && hud.enabled) {

            context.fill(8, 8, 160, 47, 0xDD101018);
            context.fill(8, 8, 12, 47, PURPLE);

            context.drawText(
                mc.textRenderer,
                "VANTA CLIENT",
                19, 14, PURPLE, false
            );

            context.drawText(
                mc.textRenderer,
                "FPS: " + mc.getCurrentFps(),
                19, 30, 0xFFFFFFFF, false
            );
        }

        if (coordinates != null && coordinates.enabled) {

            String xyz = String.format(
                "XYZ: %.1f %.1f %.1f",
                mc.player.getX(),
                mc.player.getY(),
                mc.player.getZ()
            );

            context.fill(8, 52, 200, 73, 0xDD101018);

            context.drawText(
                mc.textRenderer,
                xyz,
                15, 59, 0xFFFFFFFF, false
            );
        }

        if (playerInfo != null && playerInfo.enabled) {

            context.fill(8, 78, 180, 99, 0xDD101018);

            context.drawText(
                mc.textRenderer,
                "Player: " + mc.player.getName().getString(),
                15, 85, 0xFFFFFFFF, false
            );
        }
    }

    // GUI

    static class VantaGUI extends Screen {

        private Category selected = Category.MOVEMENT;

        private int px;
        private int py;

        private final int widthPanel = 570;
        private final int heightPanel = 390;

        VantaGUI() {
            super(Text.literal("VANTA CLIENT"));
        }

        @Override
        protected void init() {
            px = (width - widthPanel) / 2;
            py = (height - heightPanel) / 2;
        }

        private boolean inside(
            double mx, double my,
            int x1, int y1, int x2, int y2
        ) {
            return mx >= x1 && mx <= x2
                && my >= y1 && my <= y2;
        }

        @Override
        public void render(
            DrawContext ctx,
            int mouseX,
            int mouseY,
            float delta
        ) {

            ctx.fill(0, 0, width, height, 0xCC05050C);

            // MAIN PANEL

            ctx.fill(
                px, py,
                px + widthPanel,
                py + heightPanel,
                DARK
            );

            // HEADER

            ctx.fill(
                px, py,
                px + widthPanel,
                py + 62,
                0xFF241832
            );

            ctx.fill(
                px, py + 60,
                px + widthPanel,
                py + 63,
                PURPLE
            );

            ctx.drawText(
                textRenderer,
                "VANTA CLIENT",
                px + 20, py + 14,
                0xFFFFFFFF, false
            );

            ctx.drawText(
                textRenderer,
                "VERSION 2.0.0",
                px + 20, py + 34,
                PURPLE, false
            );

            // SIDEBAR

            int sx = px + 15;
            int sy = py + 85;

            Category[] categories = Category.values();

            for (int i = 0; i < categories.length; i++) {

                Category category = categories[i];

                int y = sy + i * 55;

                boolean active = selected == category;

                boolean hover = inside(
                    mouseX, mouseY,
                    sx, y,
                    sx + 150, y + 43
                );

                int color = active
                    ? 0xFF593780
                    : hover ? 0xFF353545 : 0xFF22222D;

                ctx.fill(
                    sx, y,
                    sx + 150, y + 43,
                    color
                );

                if (active) {
                    ctx.fill(
                        sx, y,
                        sx + 4, y + 43,
                        PURPLE
                    );
                }

                ctx.drawText(
                    textRenderer,
                    category.name(),
                    sx + 15, y + 16,
                    0xFFFFFFFF, false
                );
            }

            // MODULE LIST

            int mx = px + 185;
            int my = py + 85;

            int index = 0;

            for (Module module : MODULES) {

                if (module.category != selected) continue;

                int y = my + index * 82;

                boolean hover = inside(
                    mouseX, mouseY,
                    mx, y,
                    px + widthPanel - 15,
                    y + 68
                );

                ctx.fill(
                    mx, y,
                    px + widthPanel - 15,
                    y + 68,
                    hover ? 0xFF303040 : PANEL
                );

                ctx.drawText(
                    textRenderer,
                    module.name,
                    mx + 13, y + 12,
                    0xFFFFFFFF, false
                );

                ctx.drawText(
                    textRenderer,
                    module.description,
                    mx + 13, y + 34,
                    0xFFAAAAAA, false
                );

                // LARGE CLEAR BUTTON

                int bx = px + widthPanel - 105;
                int by = y + 21;

                int buttonColor = module.enabled
                    ? 0xFF713CB0
                    : 0xFF484853;

                ctx.fill(
                    bx, by,
                    bx + 78, by + 31,
                    buttonColor
                );

                ctx.drawCenteredText(
                    textRenderer,
                    module.enabled ? "ON" : "OFF",
                    bx + 39,
                    by + 11,
                    0xFFFFFFFF
                );

                index++;
            }

            if (index == 0) {
                ctx.drawText(
                    textRenderer,
                    "No modules available",
                    mx + 15, my + 15,
                    0xFFAAAAAA, false
                );
            }

            // FOOTER

            ctx.drawText(
                textRenderer,
                "RIGHT SHIFT: CLOSE",
                px + 20,
                py + heightPanel - 25,
                0xFF888899,
                false
            );

            super.render(ctx, mouseX, mouseY, delta);
        }

        @Override
        public boolean mouseClicked(
            double mouseX,
            double mouseY,
            int button
        ) {

            if (button != 0) {
                return super.mouseClicked(mouseX, mouseY, button);
            }

            // CATEGORY CLICK

            int sx = px + 15;
            int sy = py + 85;

            Category[] categories = Category.values();

            for (int i = 0; i < categories.length; i++) {

                int y = sy + i * 55;

                if (inside(
                    mouseX, mouseY,
                    sx, y, sx + 150, y + 43
                )) {
                    selected = categories[i];
                    return true;
                }
            }

            // MODULE CLICK

            int mx = px + 185;
            int my = py + 85;

            int index = 0;

            for (Module module : MODULES) {

                if (module.category != selected) continue;

                int y = my + index * 82;

                int bx = px + widthPanel - 105;
                int by = y + 21;

                if (inside(
                    mouseX, mouseY,
                    bx, by,
                    bx + 78, by + 31
                )) {
                    module.toggle();
                    return true;
                }

                index++;
            }

            return super.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public boolean shouldPause() {
            return false;
        }
    }
}
